from Classes import Carro

carros=[]
for i in range(5):
    velocidade=int(input("Velocidade inicial: "))
    modelo= input("Modelo do carro: ")
    marca= input("marca do carro: ")
    cor=input("cor do carro: ")
    carros.append(Carro(velocidade,modelo,marca,cor))
    print ("")
    
