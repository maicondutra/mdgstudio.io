class Carro(): # modelo abstrato
    def __init__(self,velocidade,modelo,marca,cor):
        self.velocidade=velocidade
        self.modelo=modelo
        self.marca=marca
        self.cor=cor
    def andar(self): #açoes- funçoes
        print("Andando a ",self.velocidade,"km/h")
    def acelerar(self,aceleracao):
        self.velocidade=self.velocidade+aceleracao
    def frear(self,frear):
        self.velocidade=self.velocidade-frear
