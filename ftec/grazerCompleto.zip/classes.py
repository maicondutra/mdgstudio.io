import pygame


class ElementoJogo():

    def __init__(self, tela, pos_x, pos_y, img):
        self.tela = tela
        self.sprite = pygame.image.load(img)
        self.rect = pygame.Rect(
            pos_x,
            pos_y,
            self.sprite.get_width(),
            self.sprite.get_height()
        )

    def desenhar(self):
        self.tela.blit(self.sprite, self.rect)


class Nave(ElementoJogo):

    def mover(self):
        keys=pygame.key.get_pressed()

        if keys[pygame.K_UP]:
            position = self.rect.move(0, -1)
            if position.top >= 0:
                self.rect = position

        if keys[pygame.K_DOWN]:
            position = self.rect.move(0, 1)
            if position.bottom <= self.tela.get_height():
                self.rect = position

        if keys[pygame.K_LEFT]:
            position = self.rect.move(-1, 0)
            if position.left >= 0:
                self.rect = position

        if keys[pygame.K_RIGHT]:
            position = self.rect.move(1, 0)
            if position.right <= self.tela.get_width():
                self.rect = position

    def atirar(self):
        bala = Bala(self.tela, self.rect.centerx, self.rect.top -10, -1)
        return bala


class Bala(ElementoJogo):

    def __init__(self, tela, pos_x, pos_y, direcao_y):
        self.tela = tela
        self.sprite = pygame.image.load("imagens/bala.png")
        self.rect = pygame.Rect(
            pos_x - self.sprite.get_width() / 2,
            pos_y,
            self.sprite.get_width(),
            self.sprite.get_height()
        )
        self.direcao_y = direcao_y

    def mover(self):
        self.rect = self.rect.move(0, self.direcao_y)


class Alien(ElementoJogo):

    def mover(self):
        self.timer += 1
        if self.timer % 3 == 0:
            self.rect = self.rect.move(0, 1)

    def atirar(self):
        bala = Bala(self.tela, self.rect.centerx, self.rect.bottom, 1)
        return bala
