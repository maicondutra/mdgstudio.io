import sys
import pygame
from random import randrange
from classes import Nave, Alien

pygame.init()
size = width, height = 800, 600
tela = pygame.display.set_mode(size)
tiros = []
aliens = []
nave = Nave(tela, 380, 520, "imagens/nave.png")
tempo_criar = 0
jogar = True

while jogar:
    tela.fill([0,0,0])
    nave.desenhar()
    nave.mover()

    tempo_criar += 1
    if tempo_criar > 300:
        tempo_criar = 0
        pos_x = randrange(width)
        alien = Alien(tela, pos_x, -10, "imagens/alien.png")
        alien.timer = 0
        aliens.append(alien)

    for alien in aliens:
        alien.desenhar()
        alien.mover()
        #if self.rect.bottom > self.tela.get_height():
        if alien.timer % 300 == 0:
            tiros.append(alien.atirar())
    if len(aliens) > 100:
        aliens.pop(0)

    for tiro in tiros:
        if tiro.rect.colliderect(nave.rect):
            jogar = False;
        for alien in aliens:
            if tiro.rect.colliderect(alien.rect):
                tiros.remove(tiro)
                aliens.remove(alien)

        tiro.desenhar()
        tiro.mover()
    if len(tiros) > 100:
        tiros.pop(0)

    pygame.display.flip()
    pygame.time.delay(2)


    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                tiros.append(nave.atirar())
            if event.key == pygame.K_F11:
                pygame.display.set_mode(
                    size,
                    pygame.FULLSCREEN
                )
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()

print("Fim do jogo!")
